using System.Xml.Linq;

namespace Zuu_Ali
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Sxogta_Click(object sender, EventArgs e)
        {
            String Name = Smagaca.Text;
            String gender = "";
            double Age, ID;

            if (!double.TryParse(Sda_a_da.Text, out ID))
            {
                MessageBox.Show("Invalid ID", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Sda_a_da.Clear();
                Sda_a_da.Focus();
                return;
            }

            if (!double.TryParse(Sage.Text, out Age))
            {
                MessageBox.Show("Invalid Age", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Sage.Clear();
                Sage.Focus();
                return;
            }

            if (Age < 18)
            {
                MessageBox.Show("You can't enrol this course becouse you are young", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (Age > 30)
            {
                MessageBox.Show("You can't enrol this course becouse you are old", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (rag.Checked == true)
            {
                gender = "Female";
            }
            else if (Dumar.Checked == true)
            {
                gender = "Male";
            }
            else
            {
                MessageBox.Show("You must choose Male or Female", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string cource ="";




            string extra_click = "";

            if (Courses.SelectedIndex != -1)
            {
                cource = Courses.SelectedItem.ToString();

                extra_click = "Yes";

                switch (cource)
                {
                    case "C#":
                        LResult.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + cource;

                        break;
                    case "Java":
                        LResult.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + cource;
                        break;
                    case "HTML&CSS3":
                        LResult.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + cource;

                        break;
                    case "React":
                        LResult.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                            "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "couse is: " + cource;

                        break;



                }
            }
            else
            {
                MessageBox.Show("please choose at least one course.", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Extra.Checked)
            {
                extra_click = "yes";
                LResult.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                           "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "couse is: " + cource +"\n" + "The Extra is:" + extra_click;
            }
            else
            {
                //no
            }
            Smagaca.Focus();
        }


        private void Xmasax_Click(object sender, EventArgs e)
        {
            LResult.Text = "";
            rag.Checked = false;
            Dumar.Checked = false;
            Smagaca.Text = "";
            Sda_a_da.Text = "";
            Sage.Text = "";
            Courses.ClearSelected();
            Extra.Checked = false;
        }

        private void kabaxP_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}


