﻿namespace Zuu_Ali
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            Dumar = new RadioButton();
            rag = new RadioButton();
            magaca = new Label();
            sanadkaa_jirto = new Label();
            idga = new Label();
            Sage = new TextBox();
            Smagaca = new TextBox();
            Sda_a_da = new TextBox();
            Extra = new CheckBox();
            Sxogta = new Button();
            groupBox2 = new GroupBox();
            Courses = new ListBox();
            LResult = new Label();
            kabaxP = new Button();
            Xmasax = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(Dumar);
            groupBox1.Controls.Add(rag);
            groupBox1.Controls.Add(magaca);
            groupBox1.Controls.Add(sanadkaa_jirto);
            groupBox1.Controls.Add(idga);
            groupBox1.Controls.Add(Sage);
            groupBox1.Controls.Add(Smagaca);
            groupBox1.Controls.Add(Sda_a_da);
            groupBox1.ForeColor = Color.Black;
            groupBox1.Location = new Point(18, 40);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(360, 234);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Student information";
            // 
            // Dumar
            // 
            Dumar.AutoSize = true;
            Dumar.Location = new Point(182, 183);
            Dumar.Name = "Dumar";
            Dumar.Size = new Size(93, 29);
            Dumar.TabIndex = 6;
            Dumar.TabStop = true;
            Dumar.Text = "Female";
            Dumar.UseVisualStyleBackColor = true;
            // 
            // rag
            // 
            rag.AutoSize = true;
            rag.Location = new Point(35, 183);
            rag.Name = "rag";
            rag.Size = new Size(75, 29);
            rag.TabIndex = 6;
            rag.TabStop = true;
            rag.Text = "Male";
            rag.UseVisualStyleBackColor = true;
            // 
            // magaca
            // 
            magaca.BackColor = Color.White;
            magaca.ForeColor = SystemColors.ActiveCaptionText;
            magaca.Location = new Point(15, 39);
            magaca.Name = "magaca";
            magaca.Size = new Size(139, 25);
            magaca.TabIndex = 0;
            magaca.Text = "Student Name:";
            magaca.TextAlign = ContentAlignment.TopRight;
            // 
            // sanadkaa_jirto
            // 
            sanadkaa_jirto.BackColor = Color.White;
            sanadkaa_jirto.Location = new Point(15, 125);
            sanadkaa_jirto.Name = "sanadkaa_jirto";
            sanadkaa_jirto.Size = new Size(139, 25);
            sanadkaa_jirto.TabIndex = 0;
            sanadkaa_jirto.Text = "Student Age:";
            sanadkaa_jirto.TextAlign = ContentAlignment.TopRight;
            // 
            // idga
            // 
            idga.BackColor = Color.White;
            idga.Location = new Point(15, 76);
            idga.Name = "idga";
            idga.Size = new Size(139, 25);
            idga.TabIndex = 0;
            idga.Text = "Student ID:";
            idga.TextAlign = ContentAlignment.TopRight;
            // 
            // Sage
            // 
            Sage.Location = new Point(174, 125);
            Sage.Name = "Sage";
            Sage.Size = new Size(170, 31);
            Sage.TabIndex = 1;
            // 
            // Smagaca
            // 
            Smagaca.Location = new Point(174, 39);
            Smagaca.Name = "Smagaca";
            Smagaca.Size = new Size(170, 31);
            Smagaca.TabIndex = 1;
            // 
            // Sda_a_da
            // 
            Sda_a_da.Location = new Point(174, 76);
            Sda_a_da.Name = "Sda_a_da";
            Sda_a_da.Size = new Size(170, 31);
            Sda_a_da.TabIndex = 1;
            // 
            // Extra
            // 
            Extra.AutoSize = true;
            Extra.Location = new Point(208, 305);
            Extra.Name = "Extra";
            Extra.Size = new Size(154, 29);
            Extra.TabIndex = 4;
            Extra.Text = "extra-curricular";
            Extra.UseVisualStyleBackColor = true;
            // 
            // Sxogta
            // 
            Sxogta.Location = new Point(18, 419);
            Sxogta.Name = "Sxogta";
            Sxogta.Size = new Size(112, 34);
            Sxogta.TabIndex = 5;
            Sxogta.Text = "&Submit";
            Sxogta.UseVisualStyleBackColor = true;
            Sxogta.Click += Sxogta_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(Courses);
            groupBox2.Controls.Add(Extra);
            groupBox2.Controls.Add(groupBox1);
            groupBox2.Controls.Add(LResult);
            groupBox2.Controls.Add(kabaxP);
            groupBox2.Controls.Add(Xmasax);
            groupBox2.Controls.Add(Sxogta);
            groupBox2.Location = new Point(248, 102);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(448, 654);
            groupBox2.TabIndex = 4;
            groupBox2.TabStop = false;
            groupBox2.Text = "Student Management";
            // 
            // Courses
            // 
            Courses.FormattingEnabled = true;
            Courses.ItemHeight = 25;
            Courses.Items.AddRange(new object[] { "Java", "C#", "HTML & CSS3", "React" });
            Courses.Location = new Point(18, 289);
            Courses.Name = "Courses";
            Courses.Size = new Size(180, 104);
            Courses.TabIndex = 6;
            // 
            // LResult
            // 
            LResult.BackColor = Color.Fuchsia;
            LResult.Location = new Point(18, 469);
            LResult.Name = "LResult";
            LResult.Size = new Size(370, 160);
            LResult.TabIndex = 0;
            // 
            // kabaxP
            // 
            kabaxP.Location = new Point(266, 419);
            kabaxP.Name = "kabaxP";
            kabaxP.Size = new Size(112, 34);
            kabaxP.TabIndex = 5;
            kabaxP.Text = "&Exit";
            kabaxP.UseVisualStyleBackColor = true;
            kabaxP.Click += kabaxP_Click;
            // 
            // Xmasax
            // 
            Xmasax.Location = new Point(144, 419);
            Xmasax.Name = "Xmasax";
            Xmasax.Size = new Size(112, 34);
            Xmasax.TabIndex = 5;
            Xmasax.Text = "&Clear";
            Xmasax.UseVisualStyleBackColor = true;
            Xmasax.Click += Xmasax_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1407, 779);
            Controls.Add(groupBox2);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox Sda_a_da;
        private TextBox Smagaca;
        private Label idga;
        private CheckBox Extra;
        private Button Sxogta;
        private Label magaca;
        private TextBox Sage;
        private GroupBox groupBox2;
        private RadioButton Dumar;
        private RadioButton rag;
        private ListBox Courses;
        private Button kabaxP;
        private Button Xmasax;
        private Label LResult;
        private Label sanadkaa_jirto;
    }
}
