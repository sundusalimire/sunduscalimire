﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_mangment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //// Declaring variables
            String Name = Stdnamezuu.Text;
            String gender = "";
            double num,Age, ID;
            if (double.TryParse(Stdnamezuu.Text, out num))
            {
                MessageBox.Show("Invalid Name!", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Stdnamezuu.Clear();
                Stdnamezuu.Focus();
                return;
            }
            else
            {
                Name = Stdnamezuu.Text;
            }

            if (!double.TryParse(StdIdzuu.Text, out ID))
            {
                MessageBox.Show("Invalid ID", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                StdIdzuu.Clear();
                StdIdzuu.Focus();
                return;
            }
            //Age kaan wuxu aqbalaya  18 ama 30 2daan waxkaweyn ama waxkayar maqbalayo
            if (!double.TryParse(StdAgezuu.Text, out Age))
            {
                MessageBox.Show("ma aqbalaayo  Da'a", "ma aqbalaayo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                StdAgezuu.Clear();
                StdAgezuu.Focus();
                return;
            }

            if (Age < 18)
            {
                MessageBox.Show("Hadii aad da'yar soogaliso maqbalayo","waaqalad", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (Age > 30)
            {
                MessageBox.Show("Hadii aad da'weyn soogaliso maqbalayo", "waa qalad", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //dooro jinsiyada aatahay hakatagin  adoo dooranin nin ama naag
            if (Female.Checked == true)
            {
                gender = "Female";
            }
            else if (Male.Checked == true)
            {
                gender = "Male";
            }
            else
            {
                
                MessageBox.Show("wainaa doorataa jinsiyada tahay nin iyo naag", "waa qalad",MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string Cource = "";



            string extra_click = "";

            if (courseslist.SelectedIndex != -1)
            {
                Cource = courseslist.SelectedItem.ToString();

                extra_click = "Yes";

                switch (Cource)
                {
                    case "C#":
                        ResultLabel.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;

                        break;
                    case "Java":
                        ResultLabel.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;
                        break;
                    case "HTML&CSS3":
                        ResultLabel.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;

                        break;
                    case "React":
                        ResultLabel.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                            "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource;

                        break;



                }
            }
            else
            {
                MessageBox.Show("please choose at least one course.", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // fadlan hakatagin inaad tik saarto
            if (extra_curricular.Checked)
            {
                extra_click = "yes";
                ResultLabel.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                           "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource + "\n" + "The Extra is:" + extra_click;
            }
            else
            {
                //no
            }
        }
       

        private void button2_Click(object sender, EventArgs e)
        {
            Stdnamezuu.Text = "";
            StdIdzuu.Text = "";
            StdAgezuu.Text = "";
            Male.Checked = false;
            Female.Checked = false;
            extra_curricular.Checked = false;
            ResultLabel.Text = "";
            courseslist.ClearSelected();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }
    }
